package com.greatlearning.studentmanagement.controller;




import java.lang.ProcessBuilder.Redirect;
import java.text.Normalizer.Form;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.greatlearning.studentmanagement.entity.Student;
import com.greatlearning.studentmanagement.service.StudentService;

@Controller
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	
	@RequestMapping("/list")
	public String listbooks(Model theModel) {
		List<Student> student=studentService.findAll();
		theModel.addAttribute("Student",student);
		return "list-students";
	}
	
	@RequestMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		Student theStudent=new Student();
		theModel.addAttribute("student",theStudent);
		return "student-form";
	}
	
	@RequestMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("id")int theId, Model theModel) {
		Student theStudent=studentService.findById(theId);
		theModel.addAttribute("student",theStudent);
		return "student-form";
	}
	
	@RequestMapping("/save")
	public String saveBook(@RequestParam("studId")int id,@RequestParam("name")String name,@RequestParam("department") String department,
			@RequestParam("country")String country) {
		
		Student theStudent;
		System.out.println("id: "+id);
		if(id!=0) {
			theStudent=studentService.findById(id);
			theStudent.setName(name);
			theStudent.setDepartment(department);
			theStudent.setCountry(country);
		}
		else {
			theStudent=new Student();
			theStudent.setName(name);
			theStudent.setDepartment(department);
			theStudent.setCountry(country);
			
			
		
		}
		System.out.println("Before Save");
		studentService.save(theStudent);
		return "redirect:/student/list";
	}
	
	@RequestMapping("/delete")
	
	public String delete(@RequestParam("id")int theId) {
		
		studentService.deleteById(theId);
		
		return "redirect:/student/list";
	}
	
	
	
	
	
	
	
	
}
